const nodemailer = require("nodemailer");
const env = process.env.ENV.toUpperCase();
const config_service = require('../../service/dbquery/config.service');
const db = require("../../model");
const application = db.application;
const applicationMaster = db.api_application_master;
const axios = require('axios');
const commQueue = db.comm_queue;
const communication = db.communication;
const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');

exports.getAllCommQueueData = async (whereCondition) => {
    try {
        return await commQueue.findAll({
            where: whereCondition,
            limit: 200,
            order: [
                ['id', 'ASC']
            ],
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.updatecommQueue = async (updateData, whereCondition) => {
    try {
        await commQueue.update(updateData, {
            where: whereCondition,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};
exports.createCommunication = async (data) => {
    try {
        return await communication.create(data, {
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.updateCommunication = async (data, whereCondition) => {
    try {
        return await communication.update(data, {
            where: whereCondition,
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.findApplicationMasterData = async (whereCondition) => {
    try {
        return await applicationMaster.findOne({
            where: whereCondition,
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.emailTrigger = async (ele) => {
    try {
        let recipient = ele.to;
        let cc = ele.cc;
        let subject = ele.subject;
        let templateBody = ele.body;
        let objectData = ele.var_data;
        let attachments = ele.attachments;
        let template = await this.dataMappingWithVariables(templateBody, objectData);
        let emailRes = await this.sendMail(ele.env_id, recipient, cc, subject, template,attachments);
        let status;
        if (emailRes.response_type == "error") {
            status = "failed"
        } else {
            status = "processed"
        }
        const uniqueId = (ele.attempts == 0) ? (Date.now() + crypto.randomInt(0, 1000)) : (ele.comm_id);
        await this.updatecommQueue(
            {
                comm_id: uniqueId,
                status,
                attempts: ele.attempts + 1, // Increment attempts by 1
            },
            { id: ele.id } // Condition to match the record
        );
    }
    catch (err) {
        console.log("error", err);
        return;
    }
}
exports.downloadFile = async (url, filePath, retries = 3) => {
    try {
        let response = await axios.get(url, {
            responseType: 'stream',
            timeout: 60000,
          })
        const writer = fs.createWriteStream(filePath);

        await new Promise((resolve, reject) => {
            response.data.pipe(writer);
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        console.log('File downloaded successfully:', filePath);
        return filePath;
    } catch (error) {
        if (retries > 0 && (error.code === 'ETIMEDOUT' || error.code === 'ECONNRESET' || error.code === 'ENOTFOUND')) {
            console.log(`Retrying download... (${3 - retries + 1})`);
            return this.downloadFile(url, filePath, retries - 1);
        } else {
            console.error('Failed to download file:', error.message);
            throw error;
        }
    }
}


exports.sendMail = async (env_id, to, cc, subject, html, optional = null) => {
    try{
        //getting smtp config respective to the application
        let smtp_data = await config_service.getOneSmtpConfig({ env_id, deleted: 0 });
        if (!smtp_data) {
            return {
                response_type: "error",
                responseCode: 400,
                responseMessage: "SMTP details Not Found For This Application"
            }
        }
        if(smtp_data.is_external_api){
            let api_url = smtp_data.external_api_base_url;
            let from_email = smtp_data.from_email;
            let resp = await this.sendMailFromExternalApi(api_url,to,subject,html,from_email,optional); 
		if(!resp.isError){
                return {
                    response_type: "success",
                    responseCode: 200,
                    responseMessage: "Email sent successfully",
                    responseData: ""
                }
            }
            else{
                return {
                    response_type: "error",
                    responseCode: 400,
                    responseMessage: resp?.ErrorMessage
                }
            }
        }
        let arrayAttachment = [];
        for(let singleAttach of optional){
            const url = singleAttach;
            const fileName = path.basename(url);
            const projectPath = process.cwd();
            const directoryPath = path.join(projectPath, 'app', 'document');
            const filePath = path.join(directoryPath, fileName);
            if (!fs.existsSync(directoryPath)) {
                fs.mkdirSync(directoryPath, { recursive: true }); // Create the directory, including parent directories if needed
            }
            if(url.length  > 0){
                await this.downloadFile(url,filePath);
            }
            arrayAttachment.push({
                filename: fileName,
                path :  filePath
            });
        }
        let mailTransporter = nodemailer.createTransport({
            host: smtp_data.mail_host,
            port: smtp_data.mail_port,
            secure: false,
            auth: {
                user: smtp_data.mail_username,
                pass: smtp_data.mail_password,
            },
        });

        let mailDetails = {
            from: smtp_data.mail_username, to, cc, subject, html
        };
        if(arrayAttachment.length>0){
            mailDetails.attachments = arrayAttachment;
        }

        return mailTransporter.sendMail(mailDetails)
            .then(info => {
                return {
                    response_type: "success",
                    responseCode: 200,
                    responseMessage: "Email sent successfully",
                    responseData: info
                }
            })
            .catch(err => {
                console.log("mail err", err);
                return {
                    response_type: "error",
                    responseCode: 400,
                    responseMessage: err?.message
                }
            }).finally(async ()=>{
                try {
                    for(let key of arrayAttachment){
                        console.log(`Attempting to delete file: ${key.path}`);
                        if (fs.existsSync(key.path)) {
                            fs.unlinkSync(key.path); // Delete the file
                            console.log(`File ${key.path} deleted successfully.`);
                        } else {
                            console.log(`File ${key.path} does not exist.`);
                        }
                        console.log(`File ${key.path} deleted successfully.`);
                    }
                
                } catch (err) {
                    console.error(`Error deleting file `, err);
                }
            })
        }
        catch(err){
            return {
                response_type: "error",
                responseCode: 500,
                responseMessage: err?.message
            }
        }
};
exports.dataMappingWithVariables = async (template, objectData) => {
    try {
        for (const key in objectData) {
            template = template ? template.replace(new RegExp(`{${key}}`, "g"), `${objectData[key]}`) : null;
        }
        return template;
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};
exports.smsTrigger = async (ele) => {
    try {
        let mobile = ele.to;
        let template_id = ele.sender_id;
        let templateBody = ele.body;
        let objectData = ele.var_data;
        let template = await this.dataMappingWithVariables(templateBody, objectData);
        let smsRes = await this.sendSms(ele.env_id, mobile, template, template_id);
        let status;
        if(smsRes.status == 200){
            status = "delivered";
        }else{
            status = "failed";
        }
        const uniqueId = (ele.attempts == 0) ? (Date.now() + crypto.randomInt(0, 1000)) : (ele.comm_id);
        await this.updatecommQueue(
            {
                comm_id: uniqueId,
                status,
                attempts: ele.attempts + 1, // Increment attempts by 1
            },
            { id: ele.id } // Condition to match the record
        );

    }
    catch (err) {
        console.log("error", err);
        throw err
    }
}
exports.sendSms = async (env_id, mobile, smsBody, template_id) => {
    try {
        let sms_config = await config_service.getOneSmsConfig({ env_id, deleted: 0 });
        if (!sms_config) {
            return {
                response_type: "error",
                responseCode: 400,
                responseMessage: "SMS config details Not Found For This Application"
            }
        }

        const apiUrl = sms_config.base_api_url;
        const data = {
            "ToMobile": mobile,
            "Message": smsBody
          }
        let response = await axios.post(apiUrl,data);

        return response;
    }
    catch (err) {
        console.error("An error occurred:", error.message);
        throw err;
    }

};

exports.sendMailFromExternalApi = async(apiUrl,to,subject,html,from,optional=[]) => {
    let data = [];
    let obj = {
        "Subject": subject,
        "Body": html,
        "Attachments": [],
        "FromEmailID": from,
        "ToEmailID": to,
        "AppID": 1,
        "AppDataKey": "",
        "AppDataKeyValue": "",
        "AppDataSubKey": "",
        "AppDataSubKeyValue": ""
    }
    data.push(obj);
    const agent = new https.Agent({
        rejectUnauthorized: false, 
        minVersion: 'TLSv1.2',     
      }); 
    let response = await axios.post(apiUrl,data, { httpsAgent: agent });
	return response.data;
}
