const crypto = require("crypto");
const fs = require('fs');
const path = require('path');
const env = process.env.ENV.toUpperCase();

const encryptText = (text,secretKey) => {
    let iv, cipher;
    iv = crypto.createHash("sha256").update(secretKey).digest("hex").substring(0, 16);
    cipher = crypto.createCipheriv(process.env[`ENCRYPTION_ALGORITHM`], secretKey, iv);
    return cipher.update(text, "utf8", "base64") + cipher.final("base64");
};

const decryptText = (text,secretKey) => {
    let iv, decipher;
    iv = crypto.createHash("sha256").update(secretKey).digest("hex").substring(0, 16);
    decipher = crypto.createDecipheriv(process.env[`ENCRYPTION_ALGORITHM`], secretKey, iv); 
    return decipher.update(text, "base64","utf8") + decipher.final("utf8");
};

const encrypt = (text) => {
    let secretKey;
    secretKey = getKey(process.env[`APP_SALT_KEY_FILE_PATH_${env}`]);
    return encryptText(text,secretKey);
};

const decrypt = (text) => {
    let secretKey;
    secretKey = getKey(process.env[`APP_SALT_KEY_FILE_PATH_${env}`]);
    return decryptText(text,secretKey);
};

const getKey = (keyFilePath) => {
  if (fs.existsSync(keyFilePath)) {
    try {
      const key = fs.readFileSync(keyFilePath, 'utf8');
      return key.trim(); // remove any leading/trailing spaces
    } catch (error) {
      console.error('Error reading the salt key file:', error);
      process.exit(1); // terminate the process in case of error
    }
  } else {
    console.error('APP SALT KEY file not found. Please contact your administrator.');
    process.exit(1); // exit with error
  }
}

module.exports = {
    encrypt,
    decrypt
};
