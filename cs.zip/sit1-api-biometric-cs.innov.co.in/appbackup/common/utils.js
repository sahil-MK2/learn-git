const moment = require('moment');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const apiLogsService = require("../service/api_log/api_log");
const env = process.env.ENV.toUpperCase();


const getUTCDateTime = () => {
  return moment().utc().format("YYYY-MM-DD H:mm:ss");
}

const removeSlash = (my_str) => {
  return my_str.slice(1, my_str.length);
}

const checkMobile = (mobile) => {
  const indianPhoneNumberPattern = /^[6-9]\d{9}$/;
  return indianPhoneNumberPattern.test(mobile);
}

const checkMail = (email) => {
  const emails = email.split(',');
  const emailPattern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
  for (let singleEmail of emails) {
    const trimmedEmail = singleEmail.trim();
    if (!emailPattern.test(trimmedEmail)) {
      return false;
    }
  }
  return true;

}

const generateHashKey = (value) =>{
  const hash = crypto.createHash('sha256');
  hash.update(value);
  return hash.digest('hex');
}
const decodeToken = async (token)=>{
  const decode = jwt.verify(token, process.env["SECRET_KEY_JWT_"+env]);
  return decode;
}

const createApiLogs = async (req) => {
  try {
    return await apiLogsService.apiLogData(req);
  } catch (err) {
    console.error("An error occurred:", err.message);
    throw err;
  }
};

const updateApiLogsData = async (data, condition) => {
  try {
    await apiLogsService.updateApiLogsData(data, condition);
  } catch (err) {
    console.error("An error occurred:", error.message);
    throw err;
  }
};
module.exports = {
  getUTCDateTime,
  removeSlash,
  createApiLogs,
  updateApiLogsData,
  generateHashKey,
  decodeToken,
  checkMobile,
  checkMail
}


