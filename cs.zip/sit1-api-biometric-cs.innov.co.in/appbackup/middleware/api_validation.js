const cs_application_service = require('../service/dbquery/cs_application.service');
const cs_api_service = require('../service/dbquery/cs_api.service');
const cs_api_application_service = require('../service/dbquery/cs_api_application.service');
const { errorResponse } = require('../lib/response.handler');
const utils = require('../common/utils');
const commonService = require("../common/utils");
const hashing = require('../common/hashing');

exports.checkApp = async (req, res, next) => {
    const registeredApp = await cs_application_service.getOne({ env_id: req.body.env_id,deleted: 0 });
    if(req.body.env_id){
        await commonService.updateApiLogsData(
            {env_id: req.body.env_id,
            },
            { id:req.dataValues }
          );
    }
    
    if (registeredApp == null) {
        return errorResponse(req,res, 400, "APP has not been registered", {});
    }
    if (registeredApp.status == "inactive") {

        return errorResponse(req,res, 400, "APP is Inactive Please contact admin", {});

    }
    return next();
}

exports.processHashRequest = async(req,res,next) =>{
    try{
    processedData = hashing.decryptText(req.body);
    processedData = JSON.parse(processedData);
    req.body = processedData;
    console.log("req.body",req.body);
    return next();
    }catch(err){
        return errorResponse(req,res, 400, "body decryption error", err);
    }

}

exports.processHashResponse = async(req,res,next) =>{
    processedData = hashing.encryptText(JSON.stringify(req.body));
}



exports.checkapi = async (req, res, next) => {
    const activeAppApi = await cs_api_service.getOneApi({ app_api: req.originalUrl });
    if (activeAppApi == null) {
        return errorResponse(requestIdleCallback,res, 400, "API has not been configured", {});
    }
    if (activeAppApi.status == "inactive") {
        return errorResponse(req,res, 400, "API is Inactive", {});

    }
    return next();
}

exports.checkRequest = (req, res, next) => {
    try {
        let reqCheckResponse = {
            error: false,
            responseMessage: ""
        };

        if (!req.body.comm_data) {
            reqCheckResponse.responseMessage = "Please provide Full Request Body";
            return errorResponse(req,res, 400, reqCheckResponse.responseMessage, {});
        }
        const definedReqBody = {
            comm_data: [{
                comm_type: "sms or email",
                to: "string",
                cc: "",
                templateBody: "string",
                var_data: {
                    "OTP": "string"
                },
                templateId: "string",
                subject: "string",
                attachments : [
                    "string"
                ],
                ref_id: "string",
                module: 0
            }]
        }
        console.log(req.body);
        if (Array.isArray(req.body.comm_data)) {
            for (let singleRequest of req.body.comm_data) {
                if (!singleRequest.comm_type) {
                    reqCheckResponse.responseMessage = "Communication type is not present";
                    return errorResponse(req,res, 400, reqCheckResponse.responseMessage, {});
                }
                let objectKeyArr = Object.keys(singleRequest);
                if (Object.keys(singleRequest).length === Object.keys(definedReqBody.comm_data[0]).length) {
                    for (let singleReqKey of objectKeyArr) {
                        if (new Set(["comm_type","subject","templateBody","var_data","templateId","attachments","ref_id","module"]).has(singleReqKey)) {
                            continue;
                        }
                        else if (singleReqKey === "to" || (singleReqKey === "cc" && singleRequest.cc.length > 0)) {
                            if (singleRequest.comm_type == "email") {
                                let emailData = singleReqKey === "to" ? singleRequest.to : singleRequest.cc;
                                if (utils.checkMail(emailData)) {
                                    continue;
                                } else {
                                    reqCheckResponse.responseMessage = "Email is Not Valid";
                                    return errorResponse(req,res, 400, reqCheckResponse.responseMessage, {});
                                }
                            }
                            if (singleRequest.comm_type == "sms") {
    
                                if (utils.checkMobile(singleRequest.to)) {
                                    continue;
                                } else {
                                    reqCheckResponse.responseMessage = "Phone is Not Valid";
                                    return errorResponse(req,res, 400, reqCheckResponse.responseMessage, {});
                                }
    
                            }
                        }
                    }
                } else {
                    reqCheckResponse.responseMessage = "Please provide Full Request Body";
                    return errorResponse(req,res, 400, reqCheckResponse.responseMessage, {});
                }
            }
        } else {
            reqCheckResponse.responseMessage = "Please provide Full Request Body";
            return errorResponse(req,res, 400, reqCheckResponse.responseMessage, {});
        }

      
        return next();
        

    } catch (err) {
        return errorResponse(req,res, 500, "Request Body Check Error", err);
    }
}


exports.checkappApi = async (env_id, apiType) => {
    const apiApplication = await cs_api_application_service.getOne({ env_id, type: apiType, deleted: 0 });
    if (apiApplication == null) {
        return {
            response_type: "error",
            responseCode: 400,
            responseMessage: `App has not been configured to ${apiType} API`
        }
    }
    if (apiApplication.status == "inactive") {
        return {
            response_type: "error",
            responsecode: 400,
            responseMessage: "API has been disabled for this app"
        }

    }

    return { response_type: "success" }
}