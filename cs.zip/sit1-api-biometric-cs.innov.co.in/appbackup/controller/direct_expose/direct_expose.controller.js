const communication_service = require('../../service/communication/communication.service')
const { successResponse, errorResponse } = require('../../lib/response.handler');
const { checkappApi } = require('../../middleware/api_validation');
const utils = require('../../common/utils');
const hashing = require('../../common/hashing');

class DirectExpose {


    async Direct_expose(req, res) {
        try {
            let resData = [];
            for (let singleComm of req.body.comm_data) {
                if (singleComm.comm_type == 'sms') {
                    const appApiRes = await checkappApi(req.body.env_id, singleComm.comm_type);
                    if (appApiRes.response_type == "error") {
                        let resObj = { comm_type: singleComm.comm_type, status: "Not Sent", message: appApiRes.responseMessage };
                        resData.push(resObj);
                    } else {
                        let template = await communication_service.dataMappingWithVariables(singleComm.templateBody, singleComm.var_data);
                        const smsRes = await communication_service.sendSms(
                            req.body.env_id,
                            singleComm.to,
                            template,
                            singleComm.templateId
                        );
                        let resObj = { comm_type: singleComm.comm_type, message: smsRes.responseMessage };
                        let status;
                        if(smsRes.status == 200){
                            status = "delivered";
                            resObj.status = status;
                        }else{
                            status = "failed";
                            resObj.status = status;
                        }
                        resData.push(resObj);
                        //creating entry in communication table
                        await communication_service.createCommunication({
                            env_id: req.body.env_id,
                            sender_id: singleComm.templateId,
                            type: singleComm.comm_type,
                            subject: singleComm.subject,
                            body: template,
                            to: singleComm.to,
                            cc: singleComm.cc,
                            attachments: singleComm.attachments,
                            status: status,
                            created: utils.getUTCDateTime(),
                            modified: utils.getUTCDateTime(),
                            ref_id: singleComm.ref_id,
                            module: singleComm.module
                        });
                    }
                }

                if (singleComm.comm_type == 'email') {
                    const appApiRes = await checkappApi(req.body.env_id, singleComm.comm_type);
                    if (appApiRes.response_type == "error") {
                        let resObj = { comm_type: singleComm.comm_type, status: "Not Sent", message: appApiRes.responseMessage };
                        resData.push(resObj);
                    } else {
                        let template = await communication_service.dataMappingWithVariables(singleComm.templateBody, singleComm.var_data);
                        const emailRes = await communication_service.sendMail(
                            req.body.env_id,
                            singleComm.to,
                            singleComm.cc,
                            singleComm.subject,
                            template,
                            singleComm.attachments
                        );
                        let resObj = { comm_type: singleComm.comm_type, message: emailRes.responseMessage };
                        let status;
                        if (emailRes.response_type == "error") {
                            status = "failed";
                            resObj.status = status;
                        } else {
                            status = "delivered";
                            resObj.status = status;
                        }
                        resData.push(resObj);
                        //creating entry in communication table
                        await communication_service.createCommunication({
                            env_id: req.body.env_id,
                            sender_id: singleComm.templateId,
                            type: singleComm.comm_type,
                            subject: singleComm.subject,
                            body: template,
                            to: singleComm.to,
                            cc: singleComm.cc,
                            attachments: singleComm.attachments,
                            status: status,
                            created: utils.getUTCDateTime(),
                            modified: utils.getUTCDateTime(),
                            ref_id: singleComm.ref_id,
                            module: singleComm.module
                        });
                    }
                }
            }
            return successResponse(req, res, 200, "Request Processed", resData);
        } catch (err) {
            return errorResponse(req, res, 500, "Direct Expose Api Error", err);

        }


    }


}

module.exports = new DirectExpose();
