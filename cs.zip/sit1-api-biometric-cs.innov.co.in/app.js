const express = require("express");
const app = express();

const bodyParser = require('body-parser');
require('dotenv').config();
const env = process.env.ENV.toUpperCase();
app.use(express.json());
//app.use(bodyParser.json());
// Parse incoming request data as text
app.use(bodyParser.text());
app.use(bodyParser.urlencoded({ 
    extended: true 
}));

const db = require("./app/model/index");
function setupRoute() {
    const routes = require("./app/router");
    routes.setup(app);
}
setupRoute();


app.listen(process.env["PORT_" + env], () => {
    console.log(`app is running on port ${process.env["PORT_" + env]}`);
});

