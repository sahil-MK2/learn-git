const cs_api_service = require('../../service/dbquery/cs_api.service');
const cs_api_application_service = require('../../service/dbquery/cs_api_application.service');
const communicationService = require('../../service/communication/communication.service');
const { successResponse, errorResponse } = require('../../lib/response.handler');
const utils = require('../../common/utils');
const { checkappApi } = require('../../middleware/api_validation');
const commQueue = require('../../service/dbquery/commQueue.service');
const httpStatus = require("http-status");
const moment = require("moment");
const jwt = require("jsonwebtoken");
const { Op } = require('sequelize');
const env = process.env.ENV.toUpperCase();

class ServiceExpose {
	async serviceComm(req, res) {
		try {
			const env_id = req.body.env_id;
			let resData=[];
			for (let singleReq of req.body.comm_data) {
				const appApiRes = await checkappApi(env_id, singleReq.comm_type);
				if (appApiRes.response_type == "error") {
					let resObj = { comm_type: singleReq.comm_type, status: "Request Failed", message: appApiRes.responseMessage };
                    resData.push(resObj);
				}
				else{
					await commQueue.commQueueCreate(singleReq,env_id);
					let resObj = { comm_type: singleReq.comm_type, status: "Request Processed", message: appApiRes.responseMessage };
                    resData.push(resObj);
				}
			}
			return successResponse(req, res, 200, "Request Processed", resData);
		}
		catch (err) {
			return errorResponse(req, res, 500, "Service Expose Api Error", err);
		}

	}

	async trigger(req, res) {
		try {
			const condition = {
				[Op.or]: [
					{ status: 'open' },
					{
						[Op.and]: [
							{ status: 'failed' },
							{ attempts: { [Op.lt]: 3 } }
						]
					}
				]
			};
			const commQueueData = await communicationService.getAllCommQueueData(condition);
			if (commQueueData.length > 0) {
				for (const ele of commQueueData) {
					if (ele.type == 'email') {
						await communicationService.emailTrigger(ele);
					}
					else if (ele.type == 'sms') {
						await communicationService.smsTrigger(ele);
					}
				}
				return successResponse(req, res, 200, "Send Successfully", {});
			}
			return successResponse(req, res, 200, "Data is not available to process'", {});
		}
		catch (err) {
			return errorResponse(req, res, 500, err.message, err);
		}
	};

	async generatejwttoken(req, res) {
		try {
			const currentTime = utils.getUTCDateTime();
			const expireTime = moment(currentTime)
				.add(1, "hour")
				.format("YYYY-MM-DD h:mm:ss");

			let env_id = (1000).toString();
			let user_id = (9).toString();
			let logInTime = (currentTime).toString();
			let secret = (process.env["SECRET_KEY_HASHING_"+env]).toString();
			let value = env_id + user_id + logInTime + expireTime + secret;
			let token = utils.generateHashKey(value);
			const tokendata = jwt.sign({
				env_id: 1000,
				user_id: 9,
				logInTime: currentTime,
				expireTime: expireTime,
				token,

			}, process.env["SECRET_KEY_JWT_"+env], { expiresIn: '12h' });

			res.status(200).json({
				status: "Success",
				message: tokendata
			})
		}
		catch (err) {
			res.status(500).json({
				status: "Failed",
				message: err.message
			})
		}
	}
}

module.exports = new ServiceExpose();
