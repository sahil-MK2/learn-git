const jwt = require('jsonwebtoken');
const commonService = require('../common/utils');
const env = process.env.ENV.toUpperCase();
const { successResponse, errorResponse } = require('../lib/response.handler');

exports.verify = async(req,res,next)=>{
    try{
        const token = req.headers["x-access-token"];
        if(!token){
            return errorResponse(req,res, 400, "Invalid token", {});
        }
        const tokenData = await commonService.decodeToken(token);
        if(!tokenData){
            return errorResponse(req,res, 400, "Invalid token", {});
        }
        let env_id= tokenData.env_id ? (tokenData.env_id).toString():"";               
        let user_id = tokenData.user_id? (tokenData.user_id).toString():"";           
        let logInTime = tokenData.logInTime? (tokenData.logInTime).toString():"";
        let expireTime = tokenData.expireTime?(tokenData.expireTime).toString():"";       
        let secret= (process.env["SECRET_KEY_HASHING_"+env]).toString();
        let value = env_id+user_id+logInTime+expireTime+secret;

        let hashcode = commonService.generateHashKey(value);
        let jwtToken = tokenData.token? tokenData.token: "";
        if(jwtToken!= hashcode){
            return errorResponse(req,res, 400, "Invalid token", {});
        }
        req.body.env_id= env_id;
        next();
    }
    catch(err){
        return errorResponse(req,res, 400, err.message, {});
    }
    
}