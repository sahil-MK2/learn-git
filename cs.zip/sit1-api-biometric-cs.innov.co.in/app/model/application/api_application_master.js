module.exports = (sequelize, DataTypes) => {
  const application_master = sequelize.define(
    "cs_api_application_master",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      env_id: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
      },
      env_name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
      },
      type: {
        type: DataTypes.STRING,
        allowNull: false
      },
      status: {
        type: DataTypes.ENUM,
        values: ["sms", "email"]
      },
      createdAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      modifiedAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      createdBy: {
        type: DataTypes.INTEGER,
      },
      modifiedBy: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: "0",
      }
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return application_master;
};
