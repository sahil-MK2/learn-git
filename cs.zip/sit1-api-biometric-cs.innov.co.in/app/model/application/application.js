module.exports = (sequelize, DataTypes) => {
    const application = sequelize.define(
        "cs_application",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                allowNull: false,
                autoIncrement: true,
            },
            env_id: {
                type: DataTypes.STRING,
                allowNull: false,
                unique: true
            },
            client_id:{
                type:DataTypes.INTEGER,
            },
            env_name: {
                type: DataTypes.STRING,
                allowNull: false,
                unique: true
            },
            code: {
                type: DataTypes.STRING,
            },
            app_api_config: {
                type: DataTypes.JSON,
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            modifiedAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            createdBy: {
                type: DataTypes.INTEGER,
            },
            modifiedBy: {
                type: DataTypes.INTEGER,
            },
            deleted: {
                type: DataTypes.TINYINT(1),
                defaultValue: "0",
            },
            status: {
                type: DataTypes.ENUM,
                values: ["active", "inactive"],
                defaultValue: "active",
            }
        },
        {
            freezeTableName: true,
            timestamps: false,
        }
    );
    return application;
};
