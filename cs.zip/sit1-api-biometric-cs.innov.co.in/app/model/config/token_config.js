module.exports = (sequelize, DataTypes) => {
    const tokenconfig = sequelize.define(
        "cs_token_config",
        {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                allowNull: false,
                primaryKey: true
            },
            env_id: {
                type: DataTypes.STRING,
                allowNull: false
            },
            app_token: {
                type: DataTypes.STRING,
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            modifiedAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            createdBy: {
                type: DataTypes.STRING
            },
            modifiedBy: {
                type: DataTypes.STRING,
            },
            deleted: {
                type: DataTypes.TINYINT(1),
                defaultValue: "0",
            },
        },
        {
            freezeTableName: true,
            timestamps: false,
        }
    );
    return tokenconfig;
}