module.exports = (sequelize, DataTypes) => {
    const smsconfig = sequelize.define(
        "cs_sms_config",
        {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                allowNull: false,
                primaryKey: true
            },
            env_id: {
                type: DataTypes.STRING,
                allowNull: false
            },
            sender_username: {
                type: DataTypes.STRING,
                allowNull: false
            },
            sender_password: {
                type: DataTypes.STRING,
                allowNull: false
            },
            sender: {
                type: DataTypes.STRING
            },
            base_api_url: {
                type: DataTypes.STRING
            },
            type: {
                type: DataTypes.STRING
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            modifiedAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            createdBy: {
                type: DataTypes.STRING
            },
            modifiedBy: {
                type: DataTypes.STRING,
            },
            deleted: {
                type: DataTypes.TINYINT(1),
                defaultValue: "0",
            },
            status: {
                type: DataTypes.ENUM,
                values: ["active", "inactive"],
                defaultValue: "active",
            }

        },
        {
            freezeTableName: true,
            timestamps: false,
        }
    );
    return smsconfig;
}