module.exports = (sequelize, DataTypes) => {
    const smtpconfig = sequelize.define(
        "cs_smtp_config",
        {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                allowNull: false,
                primaryKey: true
            },
            env_id: {
                type: DataTypes.STRING,
                allowNull: false
            },
            mail_host: {
                type: DataTypes.STRING,
                allowNull: false
            },
            mail_port: {
                type: DataTypes.STRING,
                allowNull: false
            },
            mail_username: {
                type: DataTypes.STRING,
                allowNull: false
            },
            mail_password: {
                type: DataTypes.STRING,
                allowNull: false
            },
            is_external_api: {
                type: DataTypes.TINYINT,
                defaultValue: 0
            },
            external_api_base_url: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            from_email: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            modifiedAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            createdBy: {
                type: DataTypes.STRING
            },
            modifiedBy: {
                type: DataTypes.STRING,
            },
            deleted: {
                type: DataTypes.TINYINT(1),
                defaultValue: "0",
            },
            status: {
                type: DataTypes.ENUM,
                values: ["active", "inactive"],
                defaultValue: "active",
            }

        },
        {
            freezeTableName: true,
            timestamps: false,
        }
    );
    return smtpconfig;
}