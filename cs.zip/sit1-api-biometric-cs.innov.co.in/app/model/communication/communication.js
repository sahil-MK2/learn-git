module.exports = (sequelize, DataTypes) => {
    const communication = sequelize.define(
        "cs_communication",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                allowNull: false,
                autoIncrement: true,
            },
            env_id: {
                type: DataTypes.STRING,
                allowNull: false
            },
            sender_id: {
                type: DataTypes.STRING,
                allowNull: true
            },
            ref_id: {
                type: DataTypes.STRING,
                allowNull: false
            },
            module: {
                type: DataTypes.INTEGER,
                allowNull: false
            },
            type: {
                type: DataTypes.ENUM,
                values: ["email", "sms"],
            },
            subject: {
                type: DataTypes.STRING,
                allowNull: false
            },
            body: {
                type: DataTypes.TEXT,
                allowNull: false
            },
            to: {
                type: DataTypes.STRING,
                allowNull: false
            },
            attachments: {
                type: DataTypes.JSON,
                allowNull: true
              },
            cc: {
                type: DataTypes.STRING,
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW,
            },
            modifiedAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW,
            },
            status: {
                type: DataTypes.ENUM,
                values: ["pending", "send", "delivered", "failed"],
                defaultValue: "pending",
            },

        },
        {
            freezeTableName: true,
            timestamps: false,
        }
    );
    return communication;
};
