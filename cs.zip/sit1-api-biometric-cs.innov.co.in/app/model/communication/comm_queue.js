const { all } = require("axios");

module.exports = (sequelize, DataTypes) => {
  const comm_queue = sequelize.define(
    "cs_comm_queue",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      env_id: {
        type: DataTypes.STRING,
        allowNull: false
      },
      comm_id: {
        type: DataTypes.BIGINT,
        allowNull: false
      },
      ref_id: {
        type: DataTypes.STRING,
        allowNull: false
      },
      module: {
        type: DataTypes.INTEGER,
        allowNull: false
      },
      sender_id: {
        type: DataTypes.STRING,
        allowNull: true
      },
      type: {
        type: DataTypes.ENUM,
        values: ["email", "sms"],
      },
      subject: {
        type: DataTypes.STRING,
        allowNull: false
      },
      body: {
        type: DataTypes.TEXT,
        allowNull: false
      },
      to: {
        type: DataTypes.STRING,
        allowNull: false
      },
      cc: {
        type: DataTypes.STRING,
      },
      var_data: {
        type: DataTypes.JSON,
      },
      attachments: {
        type: DataTypes.JSON,
        allowNull: true
      },
      createdAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modifiedAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      attempts: {
        type: DataTypes.INTEGER,
        defaultValue: 0
      },
      status: {
        type: DataTypes.ENUM,
        values: ['open', 'processed', "failed"],
        defaultValue: "open",
    },

    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return comm_queue;
};
