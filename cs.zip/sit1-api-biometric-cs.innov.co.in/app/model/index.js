const { Sequelize, DataTypes } = require("sequelize");
const env = process.env.ENV.toUpperCase();
const hashingService = require("../common/hashing")

const sequelize = new Sequelize(
  hashingService.decrypt(process.env["DB_DATABASE_" + env]),
  hashingService.decrypt(process.env["DB_USERNAME_" + env]),
  hashingService.decrypt(process.env["DB_PASSWORD_" + env]),
  {
    port: hashingService.decrypt(process.env["DB_PORT_" + env]),
    host: hashingService.decrypt(process.env["DB_HOST_" + env]),
    dialect: "mysql",
    //logging: console.log,
    timezone: '+00:00', // for writing to database
  },
);

try {
  sequelize.authenticate();
  console.log("connection has been established successfully");
}
catch (error) {
  console.error("unable to connect to database", error);
}
const db = {};
db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.client = require('./application/client.js')(sequelize, DataTypes);
db.api = require('./apis/api.js')(sequelize, DataTypes);
db.modules = require('./modules/modules.js')(sequelize, DataTypes);
db.communication = require('./communication/communication.js')(sequelize, DataTypes);
db.comm_queue = require('./communication/comm_queue.js')(sequelize, DataTypes);
db.api_application_master = require('./application/api_application_master.js')(sequelize, DataTypes);
db.application = require('./application/application.js')(sequelize, DataTypes);
db.api_log = require('./apis/api_log.js')(sequelize, DataTypes);
db.sms_config = require('./config/sms_config.js')(sequelize, DataTypes);
db.smtp_config = require('./config/smtp_config.js')(sequelize, DataTypes);
db.token_config = require('./config/token_config.js')(sequelize, DataTypes);
module.exports = db;