module.exports = (sequelize, DataTypes) => {
    const module = sequelize.define(
        "cs_module",
        {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                allowNull: false,
                primaryKey: true
            },
            name: {
                type: DataTypes.STRING,
                allowNull: false
            },
            module: {
                type: DataTypes.STRING,
                allowNull: false,
                unique: true
            },
            table: {
                type: DataTypes.STRING,
                allowNull: false
            },
            status: {
                type: DataTypes.ENUM,
                values: ["active", "inactive"],
                defaultValue: "active",
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            modifiedAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            createdBy: {
                type: DataTypes.STRING
            },
            modifiedBy: {
                type: DataTypes.STRING,
            },
            deleted: {
                type: DataTypes.TINYINT(1),
                defaultValue: "0",
            }

        },
        {
            freezeTableName: true,
            timestamps: false,
        }
    );
    return module;
}