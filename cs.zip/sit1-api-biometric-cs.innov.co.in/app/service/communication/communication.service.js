const nodemailer = require("nodemailer");
const env = process.env.ENV.toUpperCase();
const config_service = require('../../service/dbquery/config.service');
const db = require("../../model");
const application = db.application;
const applicationMaster = db.api_application_master;
const axios = require('axios');
const commQueue = db.comm_queue;
const communication = db.communication;
const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');

exports.getAllCommQueueData = async (whereCondition) => {
    try {
        return await commQueue.findAll({
            where: whereCondition,
            limit: 200,
            order: [
                ['id', 'ASC']
            ],
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.updatecommQueue = async (updateData, whereCondition) => {
    try {
        await commQueue.update(updateData, {
            where: whereCondition,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};
exports.createCommunication = async (data) => {
    try {
        return await communication.create(data, {
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.updateCommunication = async (data, whereCondition) => {
    try {
        return await communication.update(data, {
            where: whereCondition,
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.findApplicationMasterData = async (whereCondition) => {
    try {
        return await applicationMaster.findOne({
            where: whereCondition,
            raw: true,
        });
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.emailTrigger = async (ele) => {
    try {
        let recipient = ele.to;
        let cc = ele.cc;
        let subject = ele.subject;
        let templateBody = ele.body;
        let objectData = ele.var_data;
        let attachments = ele.attachments;
        let template = await this.dataMappingWithVariables(templateBody, objectData);
        subject = await this.dataMappingWithVariables(subject, objectData);
        let emailRes = await this.sendMail(ele.env_id, recipient, cc, subject, template,attachments);
        let status;
        if (emailRes.response_type == "error") {
            status = "failed"
        } else {
            status = "processed"
        }
        const uniqueId = (ele.attempts == 0) ? (Date.now() + crypto.randomInt(0, 1000)) : (ele.comm_id);
        await this.updatecommQueue(
            {
                comm_id: uniqueId,
                status,
                attempts: ele.attempts + 1, // Increment attempts by 1
            },
            { id: ele.id } // Condition to match the record
        );
    }
    catch (err) {
        console.log("error", err);
        return;
    }
}

exports.sendMail = async (env_id, to, cc, subject, html, attachments = []) => {
    try{
        //getting smtp config respective to the application
        let smtp_data = await config_service.getOneSmtpConfig({ env_id, deleted: 0 });
        if (!smtp_data) {
            return {
                response_type: "error",
                responseCode: 400,
                responseMessage: "SMTP details Not Found For This Application"
            }
        }
        if(smtp_data.is_external_api){
            let api_url = smtp_data.external_api_base_url;
            let from_email = smtp_data.from_email;
            let resp = await this.sendMailFromExternalApi(api_url,to,subject,html,from_email,attachments);
            if(!resp.isError){
                return {
                    response_type: "success",
                    responseCode: 200,
                    responseMessage: "Email sent successfully",
                    responseData: ""
                }
            }
            else{
                return {
                    response_type: "error",
                    responseCode: 400,
                    responseMessage: resp?.ErrorMessage
                }
            }
        }
        let mailTransporter = nodemailer.createTransport({
            host: smtp_data.mail_host,
            port: smtp_data.mail_port,
            secure: false,
            auth: {
                user: smtp_data.mail_username,
                pass: smtp_data.mail_password,
            },
        });

        let mailDetails = {
            from: smtp_data.mail_username, to, cc, subject, html,attachments
        };

        return mailTransporter.sendMail(mailDetails)
            .then(info => {
                return {
                    response_type: "success",
                    responseCode: 200,
                    responseMessage: "Email sent successfully",
                    responseData: info
                }
            })
            .catch(err => {
                console.log("mail err", err);
                return {
                    response_type: "error",
                    responseCode: 400,
                    responseMessage: err?.message
                }
            })
        }
        catch(err){
            return {
                response_type: "error",
                responseCode: 500,
                responseMessage: err?.message
            }
        }
};
exports.dataMappingWithVariables = async (template, objectData) => {
    try {
        for (const key in objectData) {
            template = template ? template.replace(new RegExp(`{${key}}`, "g"), `${objectData[key]}`) : null;
        }
        return template;
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};
exports.smsTrigger = async (ele) => {
    try {
        let mobile = ele.to;
        let template_id = ele.sender_id;
        let templateBody = ele.body;
        let objectData = ele.var_data;
        let template = await this.dataMappingWithVariables(templateBody, objectData);
        let smsRes = await this.sendSms(ele.env_id, mobile, template, template_id);
        let status;
        if(smsRes.status == 200){
            status = "delivered";
        }else{
            status = "failed";
        }
        const uniqueId = (ele.attempts == 0) ? (Date.now() + crypto.randomInt(0, 1000)) : (ele.comm_id);
        await this.updatecommQueue(
            {
                comm_id: uniqueId,
                status,
                attempts: ele.attempts + 1, // Increment attempts by 1
            },
            { id: ele.id } // Condition to match the record
        );

    }
    catch (err) {
        console.log("error", err);
        throw err
    }
}
exports.sendSms = async (env_id, mobile, smsBody, template_id) => {
    try {
        let sms_config = await config_service.getOneSmsConfig({ env_id, deleted: 0 });
        if (!sms_config) {
            return {
                response_type: "error",
                responseCode: 400,
                responseMessage: "SMS config details Not Found For This Application"
            }
        }

        const apiUrl = sms_config.base_api_url;
        const data = {
            "ToMobile": mobile,
            "Message": smsBody
          }
        let response = await axios.post(apiUrl,data, {
            headers: {
                [process.env.THIRDPARTY_SMS_API_HEADER_KEY] : process.env.THIRDPARTY_SMS_API_HEADER_VALUE
            } 
        });

        return response;
    }
    catch (err) {
        console.error("An error occurred:", error.message);
        throw err;
    }

};

exports.sendMailFromExternalApi = async(apiUrl,to,subject,html,from,optional=[]) => {
    let data = [];
    let obj = {
        "Subject": subject,
        "Body": html,
        "Attachments": [],
        "FromEmailID": from,
        "ToEmailID": to,
        "AppID": 1,
        "AppDataKey": "",
        "AppDataKeyValue": "",
        "AppDataSubKey": "",
        "AppDataSubKeyValue": ""
    }
    data.push(obj);
    const agent = new https.Agent({
        rejectUnauthorized: false, 
        minVersion: 'TLSv1.2',     
      });
    let response = await axios.post(apiUrl,data, { httpsAgent: agent, 
        headers: {
            [process.env.THIRDPARTY_SMTP_API_HEADER_KEY] : process.env.THIRDPARTY_SMTP_API_HEADER_VALUE
        } 
    });
    return response.data;
}
