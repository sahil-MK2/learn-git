const db= require('../../model');
const apiLogsTable=db.api_log;

exports.apiLogData = async (req) => {
    try {
      const data = await apiLogsTable.create({
        api_name: req.url.replace("/", ""),
        url: req?.originalUrl,
        method: req?.method,
        request_body: JSON.stringify(req?.body),
        req_header: JSON.stringify(req?.rawHeaders),
        created_date: req?.createdDate,
        status: req?.status,
        ip: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
      });
      return data;
    } catch (error) {
      console.error("An error occurred:", error.message);
      throw error;
    }
  };

  exports.updateApiLogsData = async (responseData, whereCondition) => {
    try {
      await apiLogsTable.update(responseData, {
        where: whereCondition,
      },);
    } catch (error) {
      console.error("An error occurred:", error.message);
      throw error;
    }
  };