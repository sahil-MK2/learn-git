const db = require('../../model')
const sequelize = db.sequelize;
const { QueryTypes, Utils } = require("sequelize");
const { getUTCDateTime } = require("../../common/utils");

exports.getAll = async (whereCondition=null) => {
    try {
        return await db.api_application_master.findAll({
            where:whereCondition
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.getOne = async (whereCondition=null) => {
    try {
        return await db.api_application_master.findOne({
            where:whereCondition
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};






