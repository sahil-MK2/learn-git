const db = require('../../model')
const sequelize = db.sequelize;
const { QueryTypes, Utils } = require("sequelize");
const { getUTCDateTime } = require("../../common/utils");

exports.getAllApis = async (whereCondition=null) => {
    try {
        return await db.api.findAll({
            where:whereCondition
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.getOneApi = async (whereCondition=null) => {
    try {
        return await db.api.findOne({
            where:whereCondition
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};






