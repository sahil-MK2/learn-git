const db = require('../../model')
const sequelize = db.sequelize;
const commQueue= db.comm_queue;
const { QueryTypes, Utils } = require("sequelize");
const { getUTCDateTime } = require("../../common/utils");

exports.commQueueCreate = async (bodyData,env_id) => {
    try {
        const data = await commQueue.create({
            comm_id:"",
            env_id,
            sender_id: bodyData?.templateId,
            type: bodyData?.comm_type,
            subject: bodyData?.subject,
            body: bodyData?.templateBody,
            to:bodyData?.to,
            cc:bodyData?.cc,
            var_data:bodyData?.var_data,
            attachments: bodyData?.attachments,
            status:'open',
            ref_id: bodyData?.ref_id,
            module: bodyData?.module
        });
;        return data;
    } catch (error) {
        console.error("An error occurred:", error.message);
         throw error;
    }
};
