const db = require('../../model')
const sequelize = db.sequelize;
const { QueryTypes, Utils } = require("sequelize");
const { getUTCDateTime } = require("../../common/utils");

exports.getAllSmsConfig = async (whereCondition=null) => {
    try {
        return await db.sms_config.findAll({
            where:whereCondition
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.getOneSmsConfig = async (whereCondition=null) => {
    try {
        return await db.sms_config.findOne({
            where:whereCondition
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.getAllSmtpConfig = async (whereCondition=null) => {
    try {
        return await db.smtp_config.findAll({
            where:whereCondition
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

exports.getOneSmtpConfig = async (whereCondition=null) => {
    try {
        return await db.smtp_config.findOne({
            where:whereCondition,
            raw:true
        });
        
    } catch (error) {
        console.error("An error occurred:", error.message);
        throw error;
    }
};

