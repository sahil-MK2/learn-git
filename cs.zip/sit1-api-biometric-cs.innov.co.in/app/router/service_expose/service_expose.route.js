const express = require('express');
const router = express.Router();
const serviceExpose = require('../../controller/service_expose/service_expose.controller');
const apiLog = require('../../middleware/api_log');
const verifyToken = require('../../middleware/verifyToken');
const api_validation = require('../../middleware/api_validation');

router.post('/expose',
    //api_validation.processHashRequest,
    apiLog.cratelogtable,
    verifyToken.verify ,
    api_validation.checkRequest,
    api_validation.checkApp,
    api_validation.checkapi,
    serviceExpose.serviceComm);
router.get('/trigger',apiLog.cratelogtable, serviceExpose.trigger);
router.post('/getjwt',serviceExpose.generatejwttoken);


module.exports = router;