const express = require('express');
const router = express.Router();
const direct_expose_controller = require('../../controller/direct_expose/direct_expose.controller');
const api_validation = require('../../middleware/api_validation')
const apiLog = require('../../middleware/api_log');
const verifyToken = require('../../middleware/verifyToken');

router.post('/direct',
    //api_validation.processHashRequest,
    apiLog.cratelogtable,
    verifyToken.verify ,  
    api_validation.checkRequest,
    api_validation.checkApp,
    api_validation.checkapi,
    direct_expose_controller.Direct_expose
);



module.exports = router;