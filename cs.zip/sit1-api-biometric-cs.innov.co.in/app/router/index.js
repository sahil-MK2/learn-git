"use strict"
exports.setup = function (app) {
    console.log("setting router");
    const direct_expose_router = require('./direct_expose/direct_expose.route');
    const serviceExpose = require('./service_expose/service_expose.route');

    app.get('/',(req,res)=>{res.send("server is up and running")});    
    app.use('/api/directcs',direct_expose_router);    
    app.use('/api/service',serviceExpose);
}

