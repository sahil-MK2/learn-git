module.exports = (sequelize, DataTypes) => {
    const apiLogs = sequelize.define(
        "cs_api_log",
        {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                allowNull: false,
                primaryKey: true
            },
            env_id: {
                type: DataTypes.STRING
            },
            api_name: {
                type: DataTypes.STRING
            },
            url: {
                type: DataTypes.STRING
            },
            method: {
                type: DataTypes.STRING,
            },
            request_body: {
                type: DataTypes.TEXT
            },
            req_header: {
                type: DataTypes.TEXT
            },
            response: {
                type: DataTypes.TEXT
            },
            status: {
                type: DataTypes.ENUM,
                values: ["Requested", "Success", "Failed"],
                defaultValue: "Requested",
            },
            ip: {
                type: DataTypes.STRING
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            createdAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            modifiedAt: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW
            },
            deleted: {
                type: DataTypes.TINYINT(1),
                defaultValue: "0",
            },


        },
        {
            freezeTableName: true,
            timestamps: false,
        }
    );
    return apiLogs;
}