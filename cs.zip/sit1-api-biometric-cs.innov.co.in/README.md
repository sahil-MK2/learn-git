# Techfour_CS_Node
<!-- communication service is microservice written in node for sms &amp; email trigger -->
To facilitate seamless and effective communication, our service aims to provide a reliable and versatile platform for sending emails and SMS. Our primary objective is to enhance connectivity by offering a user-friendly and efficient means for individuals and businesses to communicate with their audiences. We prioritize delivering messages promptly, ensuring high deliverability rates, and providing customizable features to meet diverse communication needs. Through our service, we strive to empower users with a robust and secure solution that simplifies the process of sending both emails and SMS, promoting engagement, and fostering clear and timely communication channels. 


Tech Details
* API-Node.js  
* Framwork-Express.js
* Unit test cases - jest
* ORM sequelize

Application Setup Details
* Install node module run npm i 
* Setup .env configuration 
* to start application npm run start
* to run the test cases npm run test

Guidelines
* Need to follow camelcase naming convention to declare variable and functions
* Make sure you are testing the edge cases also for the functionality that you are building
* Make sure you are defining the return type of each function 
* String should be wrapped in single quote instead of double quote 